/*
desevolver un trigger que impida que xoguen mais de 5 xogadores.
nome do trigger: t2_limitexogp.sql
para borrar: delete from xoga where codx='x14';
ejemplo de uso: 
insert into xoga values ('x14','p1',4,0);
rexeitada por que o partido o xogarian mais de 5 xogadores

insert into xoga values ('x5','p3',4,0);
rexeitada por que o partido p3 ainda non tiña 5 xogadores

*/

drop trigger if exists t2_limitexogp on xoga;
create or replace function ft2_limitexogp() returns trigger language plpgsql as $$
declare
contapartidos integer;


begin
 select count(*) into contapartidos from xoga where codpar=new.codpar;
 
 if contapartidos=5 then
 -- raise exception mostra algo e rompe o programa
 raise exception 'inserxion rexeitada, xa hai 5 xogadores no partido %',new.codpar;
 end if; 
 
 return new; -- hay que pones esto antes del end
end;$$
; -- punto y coma despues del dolar-dolar IMPORTANTE
create trigger t2_limitexogp before insert on xoga for each row execute procedure ft2_limitexogp()























