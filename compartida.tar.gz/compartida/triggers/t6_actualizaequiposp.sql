/*
trigger : t6_actualizaequiposp
cada vez que se inxiro un xogador na taboa xogador debe aumentar en 1 o numero de xogadores (campo numx) da do seu equipo (taboa equipo)
insert into xogador values ('x17','benito','e2',3000,0,null);
delete from xogador where codx='x17';

editado: este trigger salta si añades, cambias o borras algun xogador cambian numx de equipo
*/

drop trigger if exists t6_actualizaequiposp on xogador;
create or replace function ft6_actualizaequiposp() returns trigger language plpgsql as $$
declare



begin
-- TG_OP trigger opction
 if (TG_OP='INSERT') then
    update equipo set numx=numx+1 where codequ=new.codequ;
    raise notice 'aceptada insercion, o numero de integrantes do equipo se ha actualizado';
 elseif (TG_OP='UPDATE') then
    update equipo set numx=numx+1 where codequ=new.codequ;
    update equipo set numx=numx-1 where codequ=old.codequ;
 elseif (TG_OP='DELETE') then
    update equipo set numx=numx-1 where codequ=old.codequ;
 end if;
 return null;
end;$$
;
create trigger t6_actualizaequiposp after insert or delete or update of codequ on xogador for each row execute procedure ft6_actualizaequiposp()
























