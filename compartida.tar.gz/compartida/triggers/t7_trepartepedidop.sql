/*impide que un re4partidor reparta pedidos a clientes que habiten zonas diferentes a o que este asignado

insert into carga values ('p13','z1',1,2,'12/2/2024',18)*/

drop trigger if exists t7_trepartepedidop on carga; 

create or replace function ft7_trepartepedidop() returns trigger language plpgsql as $$

declare

z varchar;

begin

select c.codz into z from cliente c,pedido p where c.nif=p.nif and codp=new.codp;

if z<>new.codz then

raise exception 'Insercion rexeitada. O destino do pedido esta fora da area do traballo do repartidor asignado a esta carga';

end if;

return new;

end;$$
;
create trigger t7_trepartepedidop before insert on carga for each row execute procedure ft7_trepartepedidop()
