/*
trigger : t6_tactualizaequipos3p
trigger que actualiza el numero de jugadores de un equipo numx from equipo cuando se borra un jugador
delete from xogador where codx='x2';
*/

drop trigger if exists t6_tactualizaequipos3p on xogador;
create or replace function ft6_tactualizaequipos3p() returns trigger language plpgsql as $$
declare



begin
 update equipo set numx=numx-1 where codequ=old.codequ;
 

 
 return new;
end;$$
;
create trigger t6_tactualizaequipos3p after delete on xogador for each row execute procedure ft6_tactualizaequipos3p()
























