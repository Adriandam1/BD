/* 
desevolver un trigger que impida que un novo xogador cobre mas que o xogador que xa esta cobrando mais de todos os xogadores que xa hay na base de datos.

nome do trigger: t1_salariomaxp
coidado con por o nome do trigger igual que o nome da funcion

ejemplo de uso: insert into xogador values ('x16','luis','e1',2000,10,null);
para borrar si nos equivocamos: delete from xogador where codx='x16';
*/

drop trigger if exists t1_salariomaxp on xogador;
create or replace function ft1_salariomaxp() returns trigger language plpgsql as $$
declare
salariomaximo integer;


begin
 select max(salario) into salariomaximo from xogador;
 raise notice '%  %' , salariomaximo, new.salario; -- simple texto con los salarios
 if new.salario > salariomaximo then
 -- raise exception mostra algo e rompe o programa
 raise exception 'inserxion rexeitada por que o salario do novo xogador pasaria a ser maior do maximo que se cobra actualmente';
 end if; 
 
 return new; -- hay que pones esto antes del end
end;$$
; -- punto y coma despues del dolar-dolar IMPORTANTE
create trigger t1_salariomaxp before insert on xogador for each row execute procedure ft1_salariomaxp()























