/*impide qcargar un pedido realizado nunha data distinta a data de carga

insert into carga values ('p17','z1',1,2,'14/7/2020',18)

insert into carga values ('p17','z1',1,2,'13/7/2020',18)*/

drop trigger if exists t8_tcargap on carga; 

create or replace function ft8_tcargap() returns trigger language plpgsql as $$

declare

dt date;

begin

select data into dt from pedido where codp=new.codp;

if dt<>new.data then

raise exception 'Insercion rexeitada. Este pedido non npode cargarse nesta data';

end if;

return new;

end;$$
;
create trigger t8_tcargap before insert on carga for each row execute procedure ft8_tcargap()
