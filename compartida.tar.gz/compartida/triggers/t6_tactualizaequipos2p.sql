/*
trigger : t6_tactualizaequipos2p
trigger que actualiza el numero de jugadores de un equipo numx from equipo cuando un jugador cambia de equipo
-- cambia al jugador x2 lo mueve al equipo e4
update xogador set codequ='e4' where codx='x2';

x3=2
e4=6
*/

drop trigger if exists t6_tactualizaequipos2p on xogador;
create or replace function ft6_tactualizaequipos2p() returns trigger language plpgsql as $$
declare



begin
 -- sumamos 1 al equipo que gano un jugador
 update equipo set numx=numx+1 where codequ=new.codequ;
 -- restamos 1 al equipo que perdio un jugador
 update equipo set numx=numx-1 where codequ=old.codequ;
 

 
 return new;
end;$$
; -- punto y coma despues del dolar-dolar IMPORTANTE
-- en este hacemos "after update of codequ"
create trigger t6_tactualizaequipos2p after update of codequ on xogador for each row execute procedure ft6_tactualizaequipos2p()
























