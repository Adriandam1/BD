/*
ttotalpedido.sql
desenvovler un trigger que cando engada un novo produto na composicion dun pedido, 
actualice o campo total de dito pedido.

insert into compon values ('p1','m4',1,7);
6(precio del producto m4,1) * 7(cantidad del producto) = 42 + 15 = 57

1)Buscar o prezo do produto 'm4',1
select prezo from produto where codm='m4'and n=1;  --> 6
totalparcial= vprezo * new.cantidade

2)Multiplicar dito prezo por a cantidade 7
resultado = vprezo*new.cantidade

3)Actualizar o campo total do pedido p1, sumando o resultado da multiplicacion
anterior ao total anterior de dito pedido
update pedido set total = total+resultado where codp=new.codp;
*/

drop trigger if exists ttotalpedido on compon;
create or replace function fttotalpedido() returns trigger language plpgsql as $$

declare
vprezo integer;
resultado integer;

begin
update pedido set total = total+(select prezo from produto where codm=new.codm and n=new.n)*new.cantidade where codp=new.codp;
return new;
 
end; $$
;

create trigger ttotalpedido before insert on compon for each row execute
procedure fttotalpedido()

/*
declare
vprezo integer;
resultado integer;

begin
select prezo into vprezo from produto where codm=new.codm and n=new.n;
resultado = vprezo*new.cantidade;
update pedido set total = total+resultado where codp=new.codp;
return new;

--resultado es la nueva cantidad ingresada por el precio del producto ingresado.
-- El vprezo es el resultado de la consulta. EN SI es el precio del producto del pedido.
*/
