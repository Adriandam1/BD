/*
trigger : t3_tocupapostop
trigger chamado t3_tocupapostop que impida que un xogador poda xogar un partido nun posto (o
posto o seu numero de camiseta) que xa esta ocupado por outro xogador no mesmo partido.
E decir non podo haber mais dun xogador ocupando o mesmo posto( ou o que o mesmo xogando
co mesmo numero de mesma camiseta no mesmo partido)
insert into xoga values('x1','p3',1,0);
-- rexeitada insercion, o posto 1 xa esta ocupado por outro xogador no partido p3
insert into xoga values('x1','p3',2,0);
--rexistro insertado correctamente
*/

drop trigger if exists t3_tocupapostop on xoga;
create or replace function ft3_tocupapostop() returns trigger language plpgsql as $$
declare
conta integer;


begin
 select count(*)into conta from xoga where codpar=new.codpar and posto=new.posto;
  if conta=1 then
 -- raise exception mostra algo e rompe o programa
 raise exception 'inserxion rexeitada, este posto xa esta ocupado neste partido partido %', new.codpar;
 else
 raise notice 'aceptada insercion';
 end if; 
 
 return new; -- hay que pones esto antes del end
end;$$
; -- punto y coma despues del dolar-dolar IMPORTANTE
create trigger t3_tocupapostop before insert on xoga for each row execute procedure ft3_tocupapostop()
























