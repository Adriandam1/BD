
/*
procedemento postosnegados  que dado o dni dunha persoa devolte a lista dos postos de traballo para os que non  poderia  ser entrevistada debido a que algunhas empresas rexeitan a dita persoa.
call postosnegados('36202020');
p2
p9
p13
p8
p14
p15
p16
p17
esta persoa e rexeitada para un total de 8 postos

call postosnegados('36222222');
esta persoa e entrevistable para calquera posto de calqueira empresa
*/


create or replace procedure postosnegados(vdni varchar ) language plpgsql as $$ 
declare
vnum_persoa integer;
vcod_empresa varchar;
r varchar='';
c record;

begin
--uso dni para sacar codigo persoa
select num_persoa into strict vnum_persoa from persoas where dni=vdni;
raise notice 'codigo persoa : %',vnum_persoa;

-- uso codigo persoa para sacar la empresa incompatible
select cod_empresa into vcod_empresa from rexeita where num_persoa=vnum_persoa;
raise notice 'codigo empresa-rexeita : %',vcod_empresa;

if vcod_empresa is not null then

-- saco codigos empleo que persoa poderia solicitar(non corresponden a empresa incompatible)
for c in select cod_posto from postos where cod_empresa!=vcod_empresa loop
    r=r||c.cod_posto||E'\n';

end loop;
raise notice '%',r;

else
for c in select cod_posto from postos loop
    r=r||c.cod_posto||E'\n';

end loop;
raise notice '%',r;
end if;

end;$$







