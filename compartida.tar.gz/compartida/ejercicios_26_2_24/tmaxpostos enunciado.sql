/*
tmaxpostos
impedir que un mesmo xestor poda xestionar mais de 7 postos

exemplos:

insert into postos values ('p19', 'disenador web', 3000,365,'pe2','e8','x1');

 este xestor xa xestiona 7 postos

insert into postos values ('p19', 'disenador web', 3000,365,'pe2','e8','x2');

 insercion aceptada
*/
