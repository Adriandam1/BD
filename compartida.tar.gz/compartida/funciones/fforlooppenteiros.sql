/*
devolta a suma dos n primeiros numeros enteiros
*/
create or replace function fforlooppenteiros(n int) returns varchar language plpgsql as $$ 
declare
c int; 
begin
c=0;
for i in 1 .. n loop
c= c+i;

end loop;

return c;
end;$$
