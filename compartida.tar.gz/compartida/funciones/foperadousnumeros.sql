
create or replace function 

begin
if operando = 'suma' then
    r=n1+n2;
elseif operando='resta' then
    r=n1-n2;
elseif operando='multiplica' then
    r=n1*n2;
elseif operando='divide' then
    r=n1/n2;
end if;

return r;







 
