/*
desevenvolver unha funciona chamada fcontaxogadores tal que pasandolle o nome dun equipo devolte o numero de xogadores que ten 
*/


create or replace function fcontaxogadoresp (c varchar) returns varchar language plpgsql as $$ 
declare
r int=0;
t varchar='';
vpepita varchar;
begin
select codequ into vpepita from equipo where nomequ=c;
-- este if comprueba si el nombre del equipo que introducimos existe, y si no existe manda mensaje y termina el programa
if not found then 
    return 'equipo inexistente';
    end if;
select count(*) into r from xogador where codequ=vpepita;
return t||r;

end;$$

-- select fcontaxogadoresp('e1');
-- select fcontaxogadoresp('cuspedrinos');
--equipo inexistente: select fcontaxogadoresp('cuspedrino');














