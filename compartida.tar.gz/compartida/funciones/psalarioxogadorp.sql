/*
Crear procedemento psalarioxogadorp tal que dado o codigo dun xogador imprima o seu salario
- se o codigo aportado non existe debe imprimiser a mensaxe: 'xogador inexistente'

select fsalarioxogadorp('x1');
2000
select fsalarioxogadorp('x17');
'xogador inexistente'
extra:
select fsalarioxogadorp('x15');
'o xogador ten o salario nulo'
*/

create or replace procedure psalarioxogadorp (c varchar) language plpgsql as $$ 
declare

nom varchar;
sal varchar;

begin
select nomx,salario into STRICT nom,sal from xogador where codx=c;
if sal is null then
    raise notice 'o xogador de codigo % é nome % ten o salario nulo',c,nom;
    else
    raise notice 'o xogador de codigo % é nome % ten un salario de %',c,nom,sal;
end if;
exception
when no_data_found then 
raise notice 'o codigo % é inexistente',c;
end;$$

