/*
Crear procedemento plistaequxogp que liste codigo e nome de todos equipos e para cada un deles codigo, nome e salario dos seus xogadores.
ejercicio de doble for plistaequiposp y el for pxoequip

\i '/media/sf_compartida/funciones/plistaequxogp.sql' 
call plistaequxogp();
*/

create or replace procedure plistaequxogp() language plpgsql as $$ 
declare
r varchar='';
c record;
i record;
v integer;
s varchar;

begin

 for c in select * from equipo loop
    r=r||E'\n'|| 'equipo '||c.codequ ||' , nome '||c.nomequ||E'\n';

    -- ponemos la v a 0 para que cuente el numero de jugadores en cada loop que es cada equipo
    v=0;
    for i in select * from xogador where codequ=c.codequ loop
        v=v+1; -- hacemos contador en v para que cuente los jugadores
        if i.salario is null then
            s='nulo';
        else
            s= i.salario;
        end if;
        r=r||E'\t'|| 'xogador '||i.codx ||' , nome '||i.nomx ||' , salario '||s||E'\n';
    end loop;
 if v=0 then 
    r=r||E'\t'|| 'equipo sen xogadores'||E'\n';
    else
    -- mostramos numero de xogadores
    r = r||E'\t'|| 'numero de xogadores do equipo: '||v||E'\n';
    raise notice '%',r;
 end if;    
 end loop;
end;$$










