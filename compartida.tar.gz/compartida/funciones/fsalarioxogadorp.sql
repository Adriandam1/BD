/*
Crear funcion fsalarioxogadorp tal que dado o codigo dun xogador imprima o seu salario
- se o codigo aportado non existe debe imprimiser a mensaxe: 'xogador inexistente'

select fsalarioxogadorp('x1');
2000
select fsalarioxogadorp('x17');
'xogador inexistente'
extra:
select fsalarioxogadorp('x15');
'o xogador ten o salario nulo'
*/

create or replace function fsalarioxogadorp (c varchar) returns varchar language plpgsql as $$ 
declare

nom varchar;
vpepita varchar;

begin
/*
select salario into STRICT vpepita from xogador where codx=c;
if vpepita is null then
    vpepita = 'o xogador ten o salario nulo';
end if;

return vpepita;

exception
when no_data_found then 
return 'xogador inexistente';

end;'dolar'dolar'
*/
-- ---------------------
-- Para sacar nombre del jugador al lado del salario
select nomx,salario into STRICT nom,vpepita from xogador where codx=c;
if vpepita is null then
    vpepita = ' ten o salario nulo';
end if;

return nom||' '||vpepita;

exception
when no_data_found then 
return 'xogador inexistente';
end;$$

