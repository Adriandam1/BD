/* procedemento pcalculasalariosequiposp que calcule a media dos salarios de cada equipo e que actualice o campo 'mediasalarios' da taboa equipo con ditos valores

y luego hacemos que actualize la columna mediasalarios de la tabla equipo en la base
este procedimiento actualiza tablas, no solo imprime

\i '/media/sf_compartida/funciones/pcalculasalariosequiposp.sql' 
call pcalculasalariosequiposp();
*/
------------------------------------------------------------------


create or replace procedure pcalculasalariosequiposp() language plpgsql as $$ 
declare

i record;
r varchar='';

begin
-- le damos un alias a avg(salario) llamado m para poder llamarlo
for i in select codequ, avg(salario) m from xogador group by codequ loop
-- actualiza la columna mediasalarios de la tabla equipo en la base de datos
update equipo set mediasalarios=i.m where codequ=i.codequ;

--r=r||i.codequ||' , '||i.m||E'\n';

end loop;
--raise notice '%', r;

end;$$




















