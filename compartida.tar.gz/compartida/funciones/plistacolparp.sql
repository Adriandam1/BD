/*
Crear procedemento plistacolparp que liste nome de todos os colexiados e para cada un deles codigo, nome e data dos partidos nos que interveñen e o total dos mesmos
se algun colexiado non interviu en ningun partido 'este colexiado non interviu en ningun partido'

\i '/media/sf_compartida/funciones/plistacolparp.sql' 
call plistacolparp();
*/


create or replace procedure plistacolparp() language plpgsql as $$ 
declare

r varchar='';
c record;
i record;
v integer; -- contador partidos
a integer; -- contador total partidos
vnompar varchar;
vdata date;

begin
a=0;
 for c in select * from colexiado loop
    r=r||E'\n'|| 'Colexiado '||c.codc ||' , nome '||c.nomc||E'\n';
    v=0;

    for i in select * from partido where codpar in (select codpar from interven where             codc=c.codc) loop
        v=v+1;
        -- como usamos una tercera columna necesitamos otro select para coger los valores
        select nompar,data into vnompar,vdata from partido where codpar =i.codpar;
        r=r||E'\t'|| 'partido '||i.codpar ||' , nome '||vnompar||' , data '||vdata||E'\n';
    end loop;

    a = a+v;
    if v=0 then 
    r=r||E'\t'|| 'este colexiado non interviu en ningun partido'||E'\n';
    else
    r = r||E'\t'|| 'numero de partidos arbitrados: '||v||E'\n';
    end if;
 end loop; 

 r = r||'Total de partidos xogados: '||a;
 raise notice '%',r;
end;$$


















