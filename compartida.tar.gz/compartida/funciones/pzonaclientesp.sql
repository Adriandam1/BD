/*
procedemento pzonaclientesp que dado o codigo dunha zona liste nif nome e telefono dos clientes que viven nela

despois de feito a maiorers:
- 
*/
