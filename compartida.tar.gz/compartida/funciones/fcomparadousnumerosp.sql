create or replace function fcomparadousnumerosp( n1 int, n2 int) returns varchar 
language plpgsql as $$ 
 declare
 r varchar(100);
 begin
 if n1=n2 then
 r=' iguais';
 elsif n1>n2 then
 r=' primeiro maior que segundo';
 elsif n1<n2 then
 r=' primeiro menor que segundo';
 end if;
 return r;
 
 end;$$
 
 
 
 
 
 
