/*
desenvolver un procedemento chamado ppartidoestadiop no que introduzcamos o nome do estadio(exemplo 'playero') e devolta  codigo nome e data dos partidos que se xogaron nel.
o numero de partidos que se xogaron, se nos se xogaron partido que os no indique, e se o estadio non existe que tamen os no diga
call ppartidoestadiop ('playero');
*/

create or replace procedure ppartidoestadiop (vnomest varchar) language plpgsql as $$ 

declare

r varchar='';
c record;
z integer;
vcodest varchar;

begin

select codest into strict vcodest from estadio where nomest=vnomest;
z=0;
for c in select codpar,nompar,data from partido where codest=vcodest loop
--hacemos un contador para contar el numero de partidos por las vueltas del for
    z=z+1;
    r =r|| 'codigo partido'||c.codpar||' ,nome'||c.nompar||' data'||c.data||E'\n';
 end loop;
 if z=0 then
    raise notice ' nese estadio non se xogou nengun partido';
    else 
    r = r|| 'numero de partidos nese estadio: '||z;
    raise notice '%',r;
 end if;
exception 
when no_data_found then
raise notice 'estadio inexistente';
end;$$
