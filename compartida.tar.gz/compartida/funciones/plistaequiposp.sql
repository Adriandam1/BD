/*
Crear procedemento plistaequiposp que liste o codigo e nome de todos os equipos
\i '/media/sf_compartida/funciones/plistaequiposp.sql' 
call plistaequiposp();
*/

create or replace procedure plistaequiposp() language plpgsql as $$ 
declare
r varchar='';
c record;

begin
-- temos que facer un 'for loop' por que a consulta devolta mas dunha liña
 for c in select * from equipo loop
    r=r|| 'equipo '||c.codequ ||' , nome '||c.nomequ||E'\n';
 end loop;--hay que cerrar el loop
 raise notice '%',r;
end;$$







-- temos que facer un 'for loop' por que a consulta devolta mas dunha liña
-- for c in select codequ,nomequ from equipo loop
--    raise notice 'equipo %, nome %',c.codequ,c.nomequ;
-- end loop;

-- for c in select * from equipo loop
-- funcionaria igual por que solo mostramos los valores que queremos en el raise

