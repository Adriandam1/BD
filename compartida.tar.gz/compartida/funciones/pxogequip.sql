/*
Crear procedemento pxogequip que liste o codigo e nome e salario de todos os xogadores dun equipo cuxo codigo pasase por parametro
\i '/media/sf_compartida/funciones/pxogequip.sql' 
call pxogequip ('e1');
*/

create or replace procedure pxogequip (vcodequ varchar) language plpgsql as $$ 
declare
r varchar='';
c record;
s varchar;
v int=0;
vnomequ varchar;

begin
select nomequ into strict vnomequ from equipo where codequ=vcodequ;
raise notice 'equipo : %',vnomequ;
-- temos que facer un 'for loop' por que a consulta devolta mas dunha liña
 for c in select * from xogador where codequ=vcodequ loop
 v=1;
-- por que hay salarios nulos temos que facer un if para coller os nulos
    if c.salario is null then
     s='nulo';
     else
     s= c.salario;
     end if;
     r=r|| 'codigo '||c.codx ||' , nome '||c.nomx ||' , salario '||s||E'\n';
 end loop;
 if v=0 then 
 raise notice 'equipo sen xogadores';
 else
 raise notice '%',r;
 end if;
exception 
when no_data_found then
raise notice 'equipo inexistente';

end;$$

-- a variable v crease para saber si o script entra no bucle for para saber si o equipo tengo algun xogador





-- temos que facer un 'for loop' por que a consulta devolta mas dunha liña
-- for c in select codequ,nomequ from equipo loop
--    raise notice 'equipo %, nome %',c.codequ,c.nomequ;
-- end loop;

-- for c in select * from equipo loop
-- funcionaria igual por que solo mostramos los valores que queremos en el raise

