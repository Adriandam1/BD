/*
Crear procedemento plistaestparp que liste codigo e nome de todos estadios e para cada un deles codigo, nome e data dos partidos que se celebran neles.
se non se celebrou ningun partido imprimir a mensaxe 'neste estadio non se celebrou ningun partido'
e o total dos partidos por estadio
mostrar o numero total de partidos xogados
ejercicio de doble for plistaequiposp y el for pxoequip

\i '/media/sf_compartida/funciones/plistaestparp.sql' 
call plistaestparp();
*/

create or replace procedure plistaestparp() language plpgsql as $$ 
declare
r varchar='';
c record;
i record;
v integer;
a integer;
s varchar;

begin
a=0; -- iniciamos a antes del loop por que vamos a sumar los partidos en los diferentes estadios
 for c in select * from estadio loop
    r=r||E'\n'|| 'estadio '||c.codest ||' , nome '||c.nomest||E'\n';

    -- ponemos la v a 0 para que cuente el numero de jugadores en cada loop que es cada equipo
    v=0;
    for i in select * from partido where codest=c.codest loop
        v=v+1; -- hacemos contador en v para que cuente los partidos
        r=r||E'\t'|| 'partido '||i.codpar ||' , nome '||i.nompar ||' , data '||i.data||E'\n';
    end loop;
    a=a+v; -- hacemos contador en v para que cuente los partidos y declaramos r=r FUERA DEL CONTADOR para que nos sume los partidos de los estadios
 if v=0 then 
    r=r||E'\t'|| 'neste estadio non se celebrou nengun partido'||E'\n';
    else
    -- mostramos numero de partidos
    r = r||E'\t'|| 'numero de partidos xogados: '||v||E'\n';
 end if;    
 end loop;
    -- mostrar o numero total de partidos xogados
    r = r||'Total de partidos xogados: '||a;
    raise notice '%',r;
end;$$










