/*
procedemento pprodutosmarcap que dado NOME dunha marca  liste  o nome e o prezo dos productos lacteos de dita marca
 
- imprimir  tamen cantos productos lacteos ten a marca 
- se a marca non ten productos lacteos imprimir a mensaxe 'marca sen lacteos'
- se a marca non existe imprimir a mensaxe 'marca inexistente'
*/














