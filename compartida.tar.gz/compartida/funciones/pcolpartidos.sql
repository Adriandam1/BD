/*
procedimiento chamado pcolpartidos que amose para cada colexiado (codigo e nome ) o nome e as
datas dos partidos nos que interven. tamen amosar o total de partidos en que interven cda
colexiado , si non interven en nungun partido amosar a mensaxe -colexiado sen partidos arbitrados-

Podedes facer este exercicio dunha atacada pero tamen podedes facelo pouco a pouco
achegandovos a cada paso ao resultado final . Aquí vos indico os pasos posibles a seguir antes de
chegar ao resultado final:
paso 1 : amosar codigo e nome de colexiado : for ..loop para colexiados
paso 2 : engadir amosar codigos de partidosde cada colexiado : for .. loop para tabla interven
paso 3 : engadir cambiar os codigos por o nome e data dos partidos : select into en table partidos
paso 4 : engadir amosar numero de partidos arbitrados por cada colexiado e mensaxe en caso de
non arbitrar ningun

call pcolpartidos();
*/

create or replace procedure pcolpartidos() language plpgsql as $$ 
declare
r varchar=E'\n';
i record;
c record;
vnompar varchar;
vdata date;
conpar integer;

begin
for i in select codc, nomc from colexiado loop
    -- paso 1
    r= r||i.codc ||' ,'|| i.nomc||E'\n';
    conpar=0;
    -- paso 2
    for c in select codpar from interven where codc=i.codc loop
        conpar=conpar+1;
        -- paso 3
        select nompar,data into vnompar,vdata from partido where codpar=c.codpar;
        r= r||E'\t'||vnompar||' ,'||vdata||E'\n';
    end loop;
    
    -- paso 4
    if conpar= 0 then
    r=r||E'\tcolexiado sen partidos'||E'\n';
    else
    r=r||E'\ttotal: '||conpar||E'\n';
    end if;
    
end loop;
raise notice '%',r;


end;$$




























