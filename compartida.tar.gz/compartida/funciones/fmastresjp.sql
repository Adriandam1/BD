/*
Crear funcion fmastresjp tal que pasandolle o nome dun equipo devolte a mensaxe seguinte:
se o equipo ten tres xogadores: 'ten tres xogadores'
se o equipo ten mas de tres xogadores: 'ten mais de tres xogadores'
se o equipo ten menos de tres xogadores: 'ten menos de tres xogadores'
se o equipo non existe: 'equipo inexistente'
*/

create or replace function fmastresjp (c varchar) returns varchar language plpgsql as $$ 
declare
r int=0;
t varchar='';
vpepita varchar;

begin

select codequ into STRICT vpepita from equipo where nomequ=c;
select count(*) into r from xogador where codequ=vpepita;
if r=3 then
    t='ten tres xogadores';
elsif r>3 then
    t='ten mais de tres xogadores';
elsif r<3 then
    t='ten menos de tres xogadores';
end if;


return t;
exception
when no_data_found then 
return 'equipo inexistente';

end;$$

-- select fmastresjp('e1');
-- select fmastresjp('cuspedrinos');
--equipo inexistente: select fmastresjp('cuspedrino');




















