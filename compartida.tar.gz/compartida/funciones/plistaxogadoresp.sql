/*
Crear procedemento plistaxogadoresp que liste o codigo e nome e salario de todos os xogadores
\i '/media/sf_compartida/funciones/plistaxogadoresp.sql' 
call plistaxogadoresp();
*/

create or replace procedure plistaxogadoresp() language plpgsql as $$ 
declare
r varchar='';
c record;
s varchar;

begin
-- temos que facer un 'for loop' por que a consulta devolta mas dunha liña
 for c in select * from xogador loop
-- por que hay salarios nulos temos que face un if para coller os nulos
    if c.salario is null then
     s='nulo';
     else
     s= c.salario;
     end if;
     r=r|| 'codigo '||c.codx ||' , nome '||c.nomx ||' , salario '||s||E'\n';
 end loop;--hay que cerrar el loop
 raise notice '%',r;
end;$$







-- temos que facer un 'for loop' por que a consulta devolta mas dunha liña
-- for c in select codequ,nomequ from equipo loop
--    raise notice 'equipo %, nome %',c.codequ,c.nomequ;
-- end loop;

-- for c in select * from equipo loop
-- funcionaria igual por que solo mostramos los valores que queremos en el raise

