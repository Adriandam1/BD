/* procedemento pzonasclip que liste o codigo e nome de todas as zonas e para cada un delas o nif nome e telefono dos cliente que viven nelas;

\i '/media/sf_compartida/funciones/pzonasclip.sql' 
call pzonasclip();
*/

create or replace procedure pzonasclip() language plpgsql as $$ 
declare
c record;
i record;
r varchar='';
v integer;

begin
for c in select codz,nomz from zona loop
    r=r||E'\n'||c.codz ||' , zona '||c.nomz||E'\n';
    v=0;
    
    for i in select nif,nome,telefono from cliente where codz=c.codz loop
    v=v+1;
    r=r||E'\t'||i.nif ||' , nome '||i.nome||' , telefono '||i.telefono||E'\n';

    end loop;
    if v=0 then 
        r=r||' esta zona non ten clientes'||E'\n';
        
    end if;
end loop;
 raise notice '%', r;

end;$$










