/* procedemento pmediaequiposalariosp que amose os codigos e nomes de todos os equipos e para cada un deles a media dos salarios que cobran os seus xogadores

\i '/media/sf_compartida/funciones/pmediaequiposalariosp.sql' 
call pmediaequiposalariosp();

*/
-- como hay un equipo(e5) sin jugadores sale null, por lo que hay que tomar medidas
--coalesce(variable,0) cuando encuentra un null lo devuelve como 0
-- ej: r=r||'equipo '||c.codequ ||' , nome '||c.nomequ||' , salario medio: '||coalesce(media,0)||E'\n';

create or replace procedure pmediaequiposalariosp() language plpgsql as $$ 
declare

r varchar='';
c record;
conta integer;
media integer;

begin
 for c in select codequ,nomequ from equipo loop

    -- cuenta el numero de jugadores
    select count(*) into conta from xogador where codequ=c.codequ;
    -- si el equipo no tiene jugadores que lo indique, y si tiene, que haga la media
    if conta =0 then 
        r=r||'equipo '||c.codequ ||' , nome '||c.nomequ||' ,non ten xogadores'||E'\n';
        else
        select avg(salario) into media from xogador where codequ=c.codequ;
        -- si el equipo tiene jugadores, pero todos tienen salario null:
        if media is null then
        r=r||'equipo '||c.codequ ||' , nome '||c.nomequ||' , este equipo ten todos os seus xogadores con salario nulo'||E'\n';
        else
        r=r||'equipo '||c.codequ ||' , nome '||c.nomequ||' , salario medio: '||media||E'\n';
        end if;
    end if;
 end loop;

 raise notice '%',r;



end;$$




















