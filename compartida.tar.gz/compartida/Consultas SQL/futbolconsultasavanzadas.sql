1)amosar  codigo e nome de xogador e codigo e  nome do equipo no que esta
select codx, nomx, equipo.codequ from equipo,xogador where xogador.codequ=equipo.codequ;

2)amosar  codigo e nome de xogador e codigo e  nome do equipo no que esta, se hai xogadores sen equipo asignado debe amosar igualmente o seu codigo e nome de xogador
select codx, nomx, equipo.codequ from equipo right join xogador on xogador.codequ=equipo.codequ;


3)amosar  codigo e nome de xogador e codigo e  nome do equipo no que esta, se hai equipos sen xogadores asignados  debe amosarse igualmente o codigo e o nome do equipo
select codx, nomx, equipo.codequ from equipo left join xogador on xogador.codequ=equipo.codequ;

4)amosar  codigo e nome de xogador e codigo e  nome do equipo no que esta, se hai xogadores sen equipos asignados ou equipos  sen xogadores asignados  debe amosarse igualmente o codigo e o nome de distos xogadores e o codigo e nome de ditos equipos
select codx, nomx, equipo.codequ from equipo full join xogador on xogador.codequ=equipo.codequ;

5) amosara cantos xogadores ten cada equipo ( amosar codigo de equipo e numero de xogadores);
select codequ,count(*) from xogador group by codequ order by codequ;

6) amosar para cada nome de equipo cantos xogadores ten
select nomequ,count(*) from xogador,equipo where xogador.codequ=equipo.codequ group by nomequ;

7) amosar para cada nome de equipo cantos xogadores ten . se non ten xogadores debe amosarse un cero para o numero de xogadores de dito equipo
select nomequ,count(xogador.codequ) from xogador right join equipo on xogador.codequ=equipo.codequ group by nomequ;


8) amosar cantos partidos se celebran en cada estadio ( amosar codigo de estadio e numero de partidos celebradosnel )
select codest, count(*) from partido group by codest;

9) amosar para cada nome de estadio  cantos cantos partidos se celebran nel
select nomest, count(*) from partido,estadio where partido.codest=estadio.codest group by nomest;

10) amosar para cada nome de estadio  cantos cantos partidos se celebran nel . Se non se celebrou nengun partido en algun estadio debe amosarse un cero para o numero de partidos celebrados en dito estadio.
select nomest, count(partido.codest) from partido right join estadio on partido.codest=estadio.codest group by nomest;



