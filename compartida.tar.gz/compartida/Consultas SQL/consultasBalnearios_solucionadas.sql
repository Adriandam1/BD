 

1) amosar nomes de balnearios cuxo coste diario supere os 45 euros
select  nomb from balnearios where costed>45;

2) amosar nomes de pacientes que vivan na poboacion denominada brea
select nomp from pacientes where codp in (select codp from poboacions where nomp='brea');

3) indicar os tipos de augas que estarian indicadas para os pacientes que sufren de ril
select tipo from augas where coda in (select coda from indicadas where codz in (select codz from zonas_corporais where nomz='ril'));

4) amosar codigos de poboacions onde viven os pacientes  e o numero de pacientes que ten cada unha desas poboacions
select codp , count(*) from pacientes group by codp;

5) amosar de cantos minerais se compon cada tipo de auga
select tipo, count (*) from augas , compon where augas.coda=compon.coda  group by tipo;

6) amosar sen repeticion os codigos de medicos que cumplan que asignaron polo menos un balneario a un paciente  cronico e prescribiron polo menos un balneario a un enfermo agudo (e dicir, que si asignaron un balneario a un paciente cronico pero non prescribiron ningun a un paciente agudo, ou viceversa,  non deben aparecer no listado
select distinct codme from asignan where codme  in (select codme from prescriben);

7) amosar  nif e nome de todos e cada un dos pacientes e ademais a poboacion onde viven
select nif, pacientes.nomp,poboacions.nomp from pacientes left join poboacions on pacientes.codp=poboacions.codp;

8) amosar o nome do balneario  onde supostamente se atopaba  o paciente agudo de nif 3615 o 8/7/2020
select nomb from balnearios where codb in(select codb from prescriben where nif='3615'  and dea<='8/7/2020' and dsa>='8/7/2020');

9) amosar os nif de todos os pacientes se o numero de pacientes cronicos e igual  ao numero de pacientes agudos
select nif from pacientes   where  (select count(*) from cronicos) = (select count(*) from agudos);

10) amosar os nomes das poboacions que non posuan balnearios
select nomp from poboacions where codp not in (select codp from balnearios );

11) amosar nomes de balnearios que se chamen exactamente igual que nomes de poboacions
select nomp from poboacions intersect select nomb from balnearios;

12) amosar nomes de pacientes distintos aos nomes de calquera medico
select nomp from pacientes  where nomp not in (  select nomme from medicos);

13) amosar os nomes de pacientes sen que se repitan
select distinct nomp from pacientes;

14) amosar os nomes de pacientes que posuan polo menos unha letra -a- e polo menos unha letra -o- no seu  nome
select nomp from pacientes where nomp like'%a%' and nomp like '%o%';

15) amosar os nomes de todos e cada un dos medicos e os  nomes dos seus xefes
select m.nomme medico, x.nomme xefe
FROM medicos m left JOIN medicos x
ON (m.xef = x.codme);

16) amosar os nomes dos hoteis que posuan  algunha habitacion con interede (se a posue, o campo interede tera una letra s dentro)
select nomh from hoteis where codh in (select codh from habitacions where interede='s');

17) amosar cales son os ingresos mensuais  dos pacientes cronicos
select ingm from pacientes where nif in (select nif from cronicos);

18) amosar os nomes dos balnearios que posuan  fisioterapeuta
select nomb from balnearios where codb in (select codb from cat1 where fisioterapeuta='s');

19)NON FACER (max , moi DIFICIL) amosar o tipo de auga en que o mineral sodio existe en maior cantidade
mostar el piselect tipo from augato de agua en el cual el mineral 'sodio' existe en mayor cantidad
select tipo from augas where coda in (select coda from compon where codm in (select codm from minerais where nomm='sodio' and mg in (select max(mg) from compon)));


20)amosar os nomes dos pacientes cuxa estancia no hotel -melia- trancurriu en parte ou totalmente entres os dias  15/7/2020   e   20/7/2020 . E dicir que si un paciente aloxouse no hotel -melia- o dia 10/7/2020  e  deixou o hotel o dia 15/7/2020 , deberia aparecer neste listado pois transcurriu parte da sua estancia entres as datas referidas , ainda que so fose so un dia  . Pasaria o mesmo para un paciente que entrase neste hotel o dia 17/7/2020 e marchase o 24/7/2020. Ou o mesmo para un paciente que entrase o 11/7/2020 e saise o '15/7/2020';

select nomp from pacientes where nif in (select nif from aloxan where codh in (select codh from hoteis where nomh='melia') and  de<='20/7/2020' and ds>='15/7/2020' );
