// ver estructura de la tabla \d

cogemos de la tabla alimentacionp.sql

1) amosar os datos das zonas
select * from zona;
2) amosar nif e mail dos clientes
\d cliente -> select nif,mail from cliente;

3) amosar nome, nif e mail dos clientes ordeados por nome
se puede poner para ordenar por nombre: order by nome
select nif,nome,mail from cliente order by nome;

4) amosar nome, nif e mail dos clientes da zona1
select nif,nome,mail from cliente where 'z1';

5) amosar nome, nif e mail dos clientes da zona1 ordeados por nome
select nif,nome,mail from cliente where 'z1' order by nome;

6) amosar nome, nif e mail dos clientes dos que se descoñece a zona donde viven
select nif,nome,mail from cliente where codz is null;

7) amosar nome, nif e mail dos clientes dos que se coñece a zona donde viven
select nif,nome,mail from cliente where codz is not null;

8) amosar nome, nif e mail dos cliente que sexan da zona z1 ou que vivan na r/coruxo
select nif,nome,mail from cliente where codz='z1' direcion='r/coruxo';

COUNT(*) funcion de agregacion, conta filas dunha taboa
9) amosar cantos cliente hai
select count(*) from cliente;

10) amosar cantos clientes hai na zona de codigo 'z1'
select count(*) from cliente where codz='z1';

11) amosar cantos clientes nos teñen zona asignada
select count(*) from cliente where codz is null;

12) amosar os pedidos
select * from pedido;

SUM(campo) suma os valores contidos no campo especificado
13) sumar el total de  todos os pedidos
select sum(total) from pedido;

14) calcula o total final dos pedidos do cliente de nif '368h'
select sum(total) from pedido where nif='368h';

AVG(campo) calcula a media dos valores de dito campo
15) calcula media do total dos pedidos do cliente de nif '368h'
select avg(total) from pedido where nif='368h';

16) media de os pedidos p1 e p9
select avg(total) from pedido where codp='p1' or codp='p9';

17) la suma de los pedidos p10 y p11
select sum(total) from pedido where codp='10' or codp='p11';

18) la media de los pedidos con codp14,15,16 (como uno de los valores es null, realizamos /count(*) para dividirlo solo por los valores que cumplen la condicion teniendo en cuenta los nulos)
select avg(total)/count(*) from pedido where codp='p14' or codp='p15' or codp='p16';

19) cuantos pedidos no tienen total nulo (las funciones nunca tienen en cuenta los valores nulos)
select count(*) from pedido where total is not null;    /// select count(total) from pedido;




30) amosar nif, nome de clientes da zona centro
select nif, nome from cliente where codz='z1';
seria lo mismo que poner asi lo que ayuda cuando nos piden algo que hay quemirar enotra tabla:
select nif, nome from cliente where codz=(select codz from zona where nomz='centro');

31) amosa os codigos de pedidos e datas dos mesmos que fixo o cliente que ten por nif 368h
select codp,data from pedido where nif='368h';

32) amosa dni e nome dos repartidores da zona 'centro'(codz='z1')
select  dni,nomr from repartidor where codz=(select codz from zona where nomz='centro');

33) amosar nome e precio dos productos da marca argal
select nome,prezo from produto where codm=(select codm from marca where nomm='argal');

34) amosar a media dos prezos dos productos da marca argal
select avg(prezo) from produto where codm=(select codm from marca where nomm='argal');

35) amosar codigos dos pedidos cargados na furgoneta de matricula 'ab121'
select codp from carga where nf=(select nf from furgoneta where matricula='ab121');

36) amosar os codigos de pedidos que feitos por clientes que vivan na zona centro
usamos in para seleccionar multiples valores que darian en =
usar in siempre
select codp from pedido where nif in (select nif from cliente where codz=(select codz from zona where nomz='centro'));

37) amosa o numero das furgonetas onde se cargaron pedidos que fixeron os clientes da zona centro 
select nf from carga where codp in (select codp from pedido where nif in (select nif from cliente where codz in (select codz from zona where nomz='centro')));

38) amosar nome de cada produto e codigo da sua marca
select nome, codm from produto;

39) amosar nome de cada producto e o nome da sua marca
//ejemplo mostrando los codm para comprobar: select nome,produto.codm, marca.codm, nomm from produto, marca where produto.codm=marca.codm;

select nome, nomm from produto, marca where produto.codm=marca.codm;

40) amosar nome de cada cliente e a zona onde vive
select nome, nomz from cliente, zona where cliente.codz=zona.codz;

41) amosar nome do repartidor e o nome da zona onde reparte
select nomr, nomz from repartidor, zona where repartidor.codz=zona.codz;

42) amosar codigo de cada pedido cargado e matricula da furgoneta onde se carga
select codp, matricula from carga,furgoneta where carga.nf=furgoneta.nf;

43) amosar nome e orixe de cada froita
select nome, orixe from produto,froitas where froitas.codm=produto.codm and froitas.n=produto.n;

44) amosar codigos de pedido que se cargaron y el nombre del repartidor que lo cargo
select codp, nomr from carga, repartidor where carga.codz=repartidor.codz and carga.n=repartidor.n;

45) amosar codigo de cada pedido y que productos lo componen
select codp, nome from compon, produto where compon.codm=produto.codm and compon.n=produto.n;

46) amosar para cada pedido que se compon de productos, de cantos productos se compon(group by)
select codp ,count(*) from compon group by codp;

en el anterior ejercicio se pueden ordenador por codp, pero como hay mas de 10 tenemos que castear a int a partir del segundo caracter(para quitar la "p" de la lista)
select codp ,count(*) from compon group by codp order by cast(substr(codp,2)as int);
 
 
**** pregunta de examen ****

47) amosar nif e nome de TODOS OS CLIENTES e nome da zona onde viven mostrando todos teñan ou non zona asignada.
// comentado nos aparecerian solo los clientes con zona asignada
// select nif, nome, nomz from cliente,zona where cliente.codz=zona.codz;
// (6 rows)
    cuando usamos left join en vez de coma, tenemos que usar on en lugar de where
    el left join da preferencia a los datos de la tabla de la izquierda, en este caso cliente

select nif, nome, nomz from cliente left join zona  on cliente.codz=zona.codz;
//(8 rows)

    si usamos full join, daria preferencia a las 2 tablas con lo que nos saldrian todas las zonas y clientes, aunque a alguno le falte un campo del otro
// (9 rows)   


















