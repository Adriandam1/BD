 
1) Amosar os codigos dos pintores nacidos despois do ano 1455
select codp from pintores where datan>1455;

2) amosar o numero de museos existentes.
select count(*) from museos;

3)
select nomp from persoas where nomp like'%i%' or nomp like '%o%';

4) 
select nompi from pigmentos where codpa is null;

5) 
select nomp from persoas where codp in (select codp from pintores where persoas.codp=pintores.codp);

6)
select nompa from pais where codpa  not in ( select codpa from visitantes where pais.codpa=visitantes.codpa);


7)
select sum(prezo) from visitan where codm in (select codm from museos where nomm='louvre');

8)
select nompi,nompa from pigmentos left join pais on pigmentos.codpa=pais.codpa;

9)
select pintores.codp,count(n) from pintores right join cadros on pintores.codp=cadros.codp group by pintores.codp;

10)
select nomp from persoas where codp in 
(select codp from mecenas where codp in 
(select codp from apoian where codp in (
select codp from pintores where codp in 
(select codp from persoas where nomp='leonardo da vinci'))));

select nomp from persoas where copd in (select codp from pintores codp where codp in (select codp from apoian where pintores.codp=apoian.codp));

select codp from persoas where codp in (select codp from mecenas where persoas.codp=mecenas.codp) and 
codp in (select codp from apoian where apoian.codp=codpm);


*****
// sacar los nombres de las personas mecenas
select nomp from persoas where codp in 
(select codp from mecenas where persoas.codp=mecenas.codp) 
and

codp in (select codp from apoian where mecenas.codp=apoian.codpm)

// con esto saco el codp de leonardo
select codp from pintores where codp in (select codp from persoas where nomp='leonardo da vinci');

select nomp from persoas where codp in 
(select codp from mecenas where persoas.codp=mecenas.codp)
and 

codp in (select codp from apoian where codp in (
select codp from pintores where codp in (select codp from persoas where nomp='leonardo da vinci')));



select nomp from persoas where codp in 
(select codp from mecenas where persoas.codp=mecenas.codp)
and copd in (

select codp from apoian where codp in (
select codp from pintores where codp in 
(select codp from persoas where nomp='leonardo da vinci'));


select codp from persoas where copd in (select codp from pintore

select codpm from apoian where codp in (select codp from pintores where codp in (select codp from persoas where nomp='leonardo da vinci'));


select nomp from persoas where codp in (select codp from mecenas where codp=(select codpm from apoian where codp in (select codp from pintores where codp in (select codp from persoas where nomp='leonardo da vinci'))));



 
 
 
 
 
 
 
 
 
 
 
 
 
