drop table if exists Mascotas;
drop table if exists Persoas;
create table Persoas(
DNI varchar(9),
Nome varchar(15),
Apel1 varchar(15),
Apel2 varchar(15),
TLF integer,
primary key(DNI));
create table Mascotas(
CODM varchar(3),
NOMM varchar(20),
Tipo varchar(10),
Idade integer,
DNI varchar(9),
primary key(CODM),
foreign key(DNI) references Persoas(DNI));
